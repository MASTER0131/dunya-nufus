const express = require('express');
const axios = require('axios');
const app = express();

app.get('/', async (req, res) => {
    try {
        const response = await axios.get('http://data-generator:8000/stats');
        const d = response.data;

        res.send(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Canlı Dünya Sayacı</title>
                <meta charset="utf-8">
                <style>
                    body { font-family: 'Segoe UI', sans-serif; background: #0f172a; color: white; margin: 0; display: flex; justify-content: center; align-items: center; height: 100vh; }
                    .dashboard { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; width: 90%; max-width: 1000px; }
                    .card { background: #1e293b; padding: 20px; border-radius: 15px; text-align: center; border: 1px solid #334155; }
                    .main-card { grid-column: span 3; background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border: 2px solid #3b82f6; }
                    .label { color: #94a3b8; text-transform: uppercase; font-size: 0.8rem; letter-spacing: 1px; }
                    .value { font-size: 2.5rem; font-weight: bold; font-family: monospace; margin: 10px 0; }
                    .birth { color: #22c55e; } .death { color: #ef4444; } .pop { color: #3b82f6; }
                </style>
            </head>
            <body>
                <div class="dashboard">
                    <div class="card main-card">
                        <div class="label">Dünya Nüfusu</div>
                        <div id="pop" class="value pop">Yükleniyor...</div>
                    </div>
                    <div class="card">
                        <div class="label">Bugünkü Doğumlar</div>
                        <div id="births" class="value birth">0</div>
                    </div>
                    <div class="card">
                        <div class="label">Bugünkü Ölümler</div>
                        <div id="deaths" class="value death">0</div>
                    </div>
                </div>

                <script>
                    const data = ${JSON.stringify(d)};
                    
                    function update() {
                        const elapsed = (Date.now() / 1000) - data.timestamp;
                        
                        // Hesaplamalar
                        const currentPop = Math.floor(data.base_pop + (elapsed * data.rates.pop_sec));
                        const currentBirths = Math.floor(data.births_today_base + (elapsed * data.rates.birth_sec));
                        const currentDeaths = Math.floor(data.deaths_today_base + (elapsed * data.rates.death_sec));
                        
                        document.getElementById('pop').innerText = currentPop.toLocaleString();
                        document.getElementById('births').innerText = currentBirths.toLocaleString();
                        document.getElementById('deaths').innerText = currentDeaths.toLocaleString();
                    }
                    setInterval(update, 100);
                </script>
            </body>
            </html>
        `);
    } catch (err) {
        res.send("<h2>Veri çekilemedi. Python servisi kapalı olabilir.</h2>");
    }
});

app.listen(3000, '0.0.0.0');